<?php $__env->startSection('main'); ?>
<div class="row">
    <div class="col">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div><br />
        <?php endif; ?>
    </div>

    <form method="post" action="<?php echo e(route('depart-tournee.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>numTournee</label>
            <input type="text" class="form-control" name="numTournee"/>
        </div>
        <div class="form-group">
            <label>date</label>
            <input type="date" class="form-control" name="date"/>
        </div>
        <div class="form-group">
            <label>idVehicule</label>
            <input type="text" class="form-control" name="idVehicule"/>
        </div>
        <div class="form-group">
            <label>chauffeur</label>
            <input type="text" class="form-control" name="chauffeur"/>
        </div>
        <div class="form-group">
            <label>agentDeGarde</label>
            <input type="text" class="form-control" name="agentDeGarde"/>
        </div>
        <div class="form-group">
            <label>chefDeBord</label>
            <input type="text" class="form-control" name="chefDeBord"/>
        </div>

        <button type="submit" class="btn btn-primary-outline">Valider</button>
    </form>
</div>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arthur\Documents\burval\kawa\resources\views/transport/depart-tournee/index.blade.php ENDPATH**/ ?>