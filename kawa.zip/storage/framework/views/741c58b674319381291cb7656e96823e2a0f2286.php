

<?php $__env->startSection('main'); ?>
<div class="burval-container">
    <div><h2 class="heading">Heures supplémentaires recap</h2></div>
    <br/>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <br/>
    <?php endif; ?>

    <div class="row">
        <div class="col-4">
            <div class="form-group row">
                <label class="col-sm-4">Date de début</label>
                <input type="date" class="form-control col-sm-8">
            </div>
            <div class="form-group row">
                <label class="col-sm-4">Date de fin</label>
                <input type="date" class="form-control col-sm-8">
            </div>
            <!--<div class="form-group row">
                <label class="col-sm-3">Période prédifinie</label>
                <input type="date" class="form-control">
            </div>-->
        </div>
        <div class="col-2">
            <button class="btn btn-primary btn-sm">Rechercher</button>
        </div>
        <div class="col-6"></div>
    </div>
    <div class="row">
        <div class="col">
            <table class="table table-bordered" id="liste">
                <thead>
                <tr>
                    <td>Nom et prénoms convoyeur</td>
                    <td>Heures travaillées</td>
                    <td>Heures supp</td>
                    <td>Heures supp 15%</td>
                    <td>Heures supp 50%</td>
                    <td>Heures supp 75%</td>
                </tr>
                </thead>
            </table>

        </div>
    </div>

</div>
<script>
    $(document).ready(function () {
        $('#liste').DataTable({
            "language": {
                "url": "French.json"
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\BAFACOM\Documents\burval\kawa\resources\views//transport/heure-supp/recap/recap.blade.php ENDPATH**/ ?>