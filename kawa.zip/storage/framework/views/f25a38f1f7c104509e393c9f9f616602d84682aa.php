<?php $__env->startSection('main'); ?>
<div class="burval-container">
    <div><h2 class="heading">Matériel</h2></div>
    <br/>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <br/>
    <?php endif; ?>
    <div class="row">
        <div class="col">
            <table class="table table-bordered" style="width: 100%;" id="listeMateriels">
                <thead>
                <tr>
                    <th>Date</th>
                    <th>Véhicule VB</th>
                    <th>Véhicule VL</th>
                    <th>Tournée N°</th>
                    <th>Equipe CB Nom</th>
                    <th>Equipe CB Prenom</th>
                    <th>Equipe CB Fonction</th>
                    <th>Equipe CB Matricule</th>
                    <th>Equipe CC Nom</th>
                    <th>Equipe CC Prenom</th>
                    <th>Equipe CC Fonction</th>
                    <th>Equipe CC Matricule</th>
                    <th>Equipe CG Nom</th>
                    <th>Equipe CG Prenom</th>
                    <th>Equipe CG Fonction</th>
                    <th>Equipe CG Matricule</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $materiels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materiel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($materiel->date); ?></td>
                    <td><?php echo e($materiel->vehiculeVB); ?></td>
                    <td><?php echo e($materiel->vehiculeVL); ?></td>
                    <td><?php echo e($materiel->noTournee); ?></td>
                    <td><?php echo e($materiel->cbNom); ?></td>
                    <td><?php echo e($materiel->cbPrenom); ?></td>
                    <td><?php echo e($materiel->cbFonction); ?></td>
                    <td><?php echo e($materiel->cbMatricule); ?></td>
                    <td><?php echo e($materiel->ccNom); ?></td>
                    <td><?php echo e($materiel->ccPrenom); ?></td>
                    <td><?php echo e($materiel->ccFonction); ?></td>
                    <td><?php echo e($materiel->ccMatricule); ?></td>
                    <td><?php echo e($materiel->ccNom); ?></td>
                    <td><?php echo e($materiel->ccPrenom); ?></td>
                    <td><?php echo e($materiel->ccFonction); ?></td>
                    <td><?php echo e($materiel->ccMatricule); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div><br /><br />

    <p>REMETTANTS</p>
    <div class="row">
        <div class="col">
            <table class="table table-bordered" style="width: 100%;" id="listeRemettants">
                <thead>
                <tr>
                    <th>Opérateur radio</th>
                    <th>OR Nom</th>
                    <th>OR Prénom</th>
                    <th>OR Fonction</th>
                    <th>OR Matricule</th>
                    <th>OR HPS</th>
                    <th>OR HFS</th>
                    <th>Pièce de véhicule</th>
                    <th>Pièce de véhicule qté</th>
                    <th>Pièce de véhicule HR</th>
                    <th>Pièce de véhicule Conv.</th>
                    <th>Clés véhicules</th>
                    <th>Clés véhicules qté</th>
                    <th>Clés véhicules HR</th>
                    <th>Clés véhicules Conv.</th>
                    <th>Tel.</th>
                    <th>Tel. qté</th>
                    <th>Tel. HR</th>
                    <th>Tel. Conv.</th>
                    <th>Radio portative</th>
                    <th>Radio portative qté</th>
                    <th>Radio portative HR</th>
                    <th>Radio portative Conv.</th>
                    <th>GBP</th>
                    <th>GBP qté</th>
                    <th>GBP HR</th>
                    <th>GBP Conv.</th>
                    <th>PA</th>
                    <th>PA qté</th>
                    <th>PA HR</th>
                    <th>PA Conv.</th>
                    <th>FP</th>
                    <th>FP qté</th>
                    <th>FP HR</th>
                    <th>FP Conv.</th>
                    <th>PM</th>
                    <th>PM qté</th>
                    <th>PM HR</th>
                    <th>PM conv.</th>
                    <th>Minutions</th>
                    <th>Minutions Qté</th>
                    <th>Minutions HR</th>
                    <th>Minutions Conv.</th>
                    <th>TAG</th>
                    <th>TAG qté</th>
                    <th>TAG HR</th>
                    <th>TAG Conv.</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $remettants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $remettant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($remettant->materiels->operateurRadio); ?></td>
                        <td><?php echo e($remettant->materiels->operateurRadioNom); ?></td>
                        <td><?php echo e($remettant->materiels->operateurRadioPrenom); ?></td>
                        <td><?php echo e($remettant->materiels->operateurRadioFonction); ?></td>
                        <td><?php echo e($remettant->materiels->operateurRadioMatricule); ?></td>
                        <td><?php echo e($remettant->materiels->operateurRadioHeurePrise); ?></td>
                        <td><?php echo e($remettant->materiels->operateurRadioHeureFin); ?></td>
                        <td><?php echo e($remettant->remettantPieceVehicule); ?></td>
                        <td><?php echo e($remettant->remettantPieceVehiculeQuantite); ?></td>
                        <td><?php echo e($remettant->remettantPieceVehiculeHeureRetour); ?></td>
                        <td><?php echo e($remettant->remettantPieceVehiculeConvoyeur); ?></td>
                        <td><?php echo e($remettant->remettantCleVehicule); ?></td>
                        <td><?php echo e($remettant->remettantCleVehiculeQuantite); ?></td>
                        <td><?php echo e($remettant->remettantCleVehiculeHeureRetour); ?></td>
                        <td><?php echo e($remettant->remettantCleVehiculeConvoyeur); ?></td>
                        <td><?php echo e($remettant->remettantTelephone); ?></td>
                        <td><?php echo e($remettant->remettantTelephoneQuantite); ?></td>
                        <td><?php echo e($remettant->remettantTelephoneHeureRetour); ?></td>
                        <td><?php echo e($remettant->remettantTelephoneConvoyeur); ?></td>
                        <td><?php echo e($remettant->remettantRadio); ?></td>
                        <td><?php echo e($remettant->remettantRadioQuantite); ?></td>
                        <td><?php echo e($remettant->remettantRadioHeureRetour); ?></td>
                        <td><?php echo e($remettant->remettantRadioConvoyeur); ?></td>
                        <td><?php echo e($remettant->remettantGBP); ?></td>
                        <td><?php echo e($remettant->remettantGBPQuantite); ?></td>
                        <td><?php echo e($remettant->remettantGBPHeureRetour); ?></td>
                        <td><?php echo e($remettant->remettantGBPConvoyeur); ?></td>
                        <td><?php echo e($remettant->remettantPA); ?></td>
                        <td><?php echo e($remettant->remettantPAQuantite); ?></td>
                        <td><?php echo e($remettant->remettantPAHeureRetour); ?></td>
                        <td><?php echo e($remettant->remettantPAConvoyeur); ?></td>
                        <td><?php echo e($remettant->remettantFP); ?></td>
                        <td><?php echo e($remettant->remettantFPQuantite); ?></td>
                        <td><?php echo e($remettant->remettantFPHeureRetour); ?></td>
                        <td><?php echo e($remettant->remettantFPConvoyeur); ?></td>
                        <td><?php echo e($remettant->remettantPM); ?></td>
                        <td><?php echo e($remettant->remettantPMQuantite); ?></td>
                        <td><?php echo e($remettant->remettantPMHeureRetour); ?></td>
                        <td><?php echo e($remettant->remettantPMConvoyeur); ?></td>
                        <td><?php echo e($remettant->remettantMunition); ?></td>
                        <td><?php echo e($remettant->remettantMunitionQuantite); ?></td>
                        <td><?php echo e($remettant->remettantMunitionHeureRetour); ?></td>
                        <td><?php echo e($remettant->remettantMunitionConvoyeur); ?></td>
                        <td><?php echo e($remettant->remettantTAG); ?></td>
                        <td><?php echo e($remettant->remettantTAGQuanite); ?></td>
                        <td><?php echo e($remettant->remettantTAGHeureRetour); ?></td>
                        <td><?php echo e($remettant->remettantTAGConvoyeur); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div><br />

    <p>BENEFICIAIRES</p>
    <div class="row">
        <div class="col">
            <table class="table table-bordered" style="width: 100%;" id="listeBeneficiaires">
                <thead>
                <tr>
                    <th>Opérateur radio</th>
                    <th>OR Nom</th>
                    <th>OR Prénom</th>
                    <th>OR Fonction</th>
                    <th>OR Matricule</th>
                    <th>OR HPS</th>
                    <th>OR HFS</th>
                    <th>Pièce de véhicule</th>
                    <th>Pièce de véhicule qté</th>
                    <th>Pièce de véhicule HR</th>
                    <th>Pièce de véhicule Conv.</th>
                    <th>Clés véhicules</th>
                    <th>Clés véhicules qté</th>
                    <th>Clés véhicules HR</th>
                    <th>Clés véhicules Conv.</th>
                    <th>Tel.</th>
                    <th>Tel. qté</th>
                    <th>Tel. HR</th>
                    <th>Tel. Conv.</th>
                    <th>Radio portative</th>
                    <th>Radio portative qté</th>
                    <th>Radio portative HR</th>
                    <th>Radio portative Conv.</th>
                    <th>GBP</th>
                    <th>GBP qté</th>
                    <th>GBP HR</th>
                    <th>GBP Conv.</th>
                    <th>PA</th>
                    <th>PA qté</th>
                    <th>PA HR</th>
                    <th>PA Conv.</th>
                    <th>FP</th>
                    <th>FP qté</th>
                    <th>FP HR</th>
                    <th>FP Conv.</th>
                    <th>PM</th>
                    <th>PM qté</th>
                    <th>PM HR</th>
                    <th>PM conv.</th>
                    <th>Minutions</th>
                    <th>Minutions Qté</th>
                    <th>Minutions HR</th>
                    <th>Minutions Conv.</th>
                    <th>TAG</th>
                    <th>TAG qté</th>
                    <th>TAG HR</th>
                    <th>TAG Conv.</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $beneficiaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beneficiaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($beneficiaire->materiels->operateurRadio); ?></td>
                        <td><?php echo e($beneficiaire->materiels->operateurRadioNom); ?></td>
                        <td><?php echo e($beneficiaire->materiels->operateurRadioPrenom); ?></td>
                        <td><?php echo e($beneficiaire->materiels->operateurRadioFonction); ?></td>
                        <td><?php echo e($beneficiaire->materiels->operateurRadioMatricule); ?></td>
                        <td><?php echo e($beneficiaire->materiels->operateurRadioHeurePrise); ?></td>
                        <td><?php echo e($beneficiaire->materiels->operateurRadioHeureFin); ?></td>
                        <td><?php echo e($beneficiaire->beneficiairePieceVehicule); ?></td>
                        <td><?php echo e($beneficiaire->beneficiairePieceVehiculeQuantite); ?></td>
                        <td><?php echo e($beneficiaire->beneficiairePieceVehiculeHeureRetour); ?></td>
                        <td><?php echo e($beneficiaire->beneficiairePieceVehiculeConvoyeur); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireCleVehicule); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireCleVehiculeQuantite); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireCleVehiculeHeureRetour); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireCleVehiculeConvoyeur); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireTelephone); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireTelephoneQuantite); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireTelephoneHeureRetour); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireTelephoneConvoyeur); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireRadio); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireRadioQuantite); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireRadioHeureRetour); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireRadioConvoyeur); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireGBP); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireGBPQuantite); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireGBPHeureRetour); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireGBPConvoyeur); ?></td>
                        <td><?php echo e($beneficiaire->beneficiairePA); ?></td>
                        <td><?php echo e($beneficiaire->beneficiairePAQuantite); ?></td>
                        <td><?php echo e($beneficiaire->beneficiairePAHeureRetour); ?></td>
                        <td><?php echo e($beneficiaire->beneficiairePAConvoyeur); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireFP); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireFPQuantite); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireFPHeureRetour); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireFPConvoyeur); ?></td>
                        <td><?php echo e($beneficiaire->beneficiairePM); ?></td>
                        <td><?php echo e($beneficiaire->beneficiairePMQuantite); ?></td>
                        <td><?php echo e($beneficiaire->beneficiairePMHeureRetour); ?></td>
                        <td><?php echo e($beneficiaire->beneficiairePMConvoyeur); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireMunition); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireMunitionQuantite); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireMunitionHeureRetour); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireMunitionConvoyeur); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireTAG); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireTAGQuanite); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireTAGHeureRetour); ?></td>
                        <td><?php echo e($beneficiaire->beneficiaireTAGConvoyeur); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>


</div>
<script>
    $(document).ready( function () {
        $('#listeMateriels').DataTable({
            "language": {
                "url": "French.json"
            }
        });
        $('#listeRemettants').DataTable({
            "language": {
                "url": "French.json"
            }
        });
        $('#listeBeneficiaires').DataTable({
            "language": {
                "url": "French.json"
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\BAFACOM\Documents\burval\kawa\resources\views/securite/materiel/liste.blade.php ENDPATH**/ ?>