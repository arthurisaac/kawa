<?php $__env->startSection('main'); ?>
<div class="burval-container">
    <div><h2 class="heading">Arrivée tournée</h2></div>
    <br/>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <br/>
    <?php endif; ?>

    <form method="post" action="<?php echo e(route('arrivee-tournee.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col">
                <div class="form-group">
                    <label>N°Tournée</label>
                    <select class="form-control" name="numeroTournee">
                        <option>Selectionnez tournée</option>
                        <?php $__currentLoopData = $departTournees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departTournee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($departTournee->id); ?>"><?php echo e($departTournee->numeroTournee); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label>Date</label>
                    <input type="text" class="form-control" name="date"/>
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label>Véhicule</label>
                    <input type="text" class="form-control" name="vehicule"/>
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label>Km départ</label>
                    <input type="text" class="form-control" name="kmDepart"/>
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label>Heure départ</label>
                    <input type="text" class="form-control" name="heureDepart"/>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="form-group">
                    <label>Convoyeur1</label>
                    <input type="text" class="form-control" name="convoyeur1"/>
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label>Convoyeur 2</label>
                    <input type="text" class="form-control" name="convoyeur2"/>
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label>Convoyeur 3</label>
                    <input type="text" class="form-control" name="convoyeur3"/>
                </div>
            </div>
        </div>
        <br/>

        <div class="row">
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 1</label>
                            <input type="text" class="form-control" name="site[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Bord</label>
                            <input type="text" class="form-control" name="bord[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Montant</label>
                            <input type="text" class="form-control" name="montant[]"/>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 2</label>
                            <input type="text" class="form-control" name="site[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Bord</label>
                            <input type="text" class="form-control" name="bord[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Montant</label>
                            <input type="text" class="form-control" name="montant[]"/>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 3</label>
                            <input type="text" class="form-control" name="site[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Bord</label>
                            <input type="text" class="form-control" name="bord[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Montant</label>
                            <input type="text" class="form-control" name="montant[]"/>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 2</label>
                            <input type="text" class="form-control" name="site[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Bord</label>
                            <input type="text" class="form-control" name="bord[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Montant</label>
                            <input type="text" class="form-control" name="montant[]"/>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 9</label>
                            <input type="text" class="form-control" name="site[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Bord</label>
                            <input type="text" class="form-control" name="bord[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Montant</label>
                            <input type="text" class="form-control" name="montant[]"/>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 16</label>
                            <input type="text" class="form-control" name="site[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Bord</label>
                            <input type="text" class="form-control" name="bord[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Montant</label>
                            <input type="text" class="form-control" name="montant[]"/>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 3</label>
                            <input type="text" class="form-control" name="site[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Bord</label>
                            <input type="text" class="form-control" name="bord[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Montant</label>
                            <input type="text" class="form-control" name="montant[]"/>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 10</label>
                            <input type="text" class="form-control" name="site[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Bord</label>
                            <input type="text" class="form-control" name="bord[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Montant</label>
                            <input type="text" class="form-control" name="montant[]"/>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 17</label>
                            <input type="text" class="form-control" name="site[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Bord</label>
                            <input type="text" class="form-control" name="bord[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Montant</label>
                            <input type="text" class="form-control" name="montant[]"/>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 4</label>
                            <input type="text" class="form-control" name="site[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Bord</label>
                            <input type="text" class="form-control" name="bord[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Montant</label>
                            <input type="text" class="form-control" name="montant[]"/>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 11</label>
                            <input type="text" class="form-control" name="site[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Bord</label>
                            <input type="text" class="form-control" name="bord[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Montant</label>
                            <input type="text" class="form-control" name="montant[]"/>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 18</label>
                            <input type="text" class="form-control" name="site[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Bord</label>
                            <input type="text" class="form-control" name="bord[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Montant</label>
                            <input type="text" class="form-control" name="montant[]"/>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 5</label>
                            <input type="text" class="form-control" name="site[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Bord</label>
                            <input type="text" class="form-control" name="bord[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Montant</label>
                            <input type="text" class="form-control" name="montant[]"/>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 12</label>
                            <input type="text" class="form-control" name="site[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Bord</label>
                            <input type="text" class="form-control" name="bord[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Montant</label>
                            <input type="text" class="form-control" name="montant[]"/>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 19</label>
                            <input type="text" class="form-control" name="site[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Bord</label>
                            <input type="text" class="form-control" name="bord[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Montant</label>
                            <input type="text" class="form-control" name="montant[]"/>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 6</label>
                            <input type="text" class="form-control" name="site[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Bord</label>
                            <input type="text" class="form-control" name="bord[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Montant</label>
                            <input type="text" class="form-control" name="montant[]"/>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 13</label>
                            <input type="text" class="form-control" name="site[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Bord</label>
                            <input type="text" class="form-control" name="bord[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Montant</label>
                            <input type="text" class="form-control" name="montant[]"/>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 20</label>
                            <input type="text" class="form-control" name="site[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Bord</label>
                            <input type="text" class="form-control" name="bord[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Montant</label>
                            <input type="text" class="form-control" name="montant[]"/>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 7</label>
                            <input type="text" class="form-control" name="site[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Bord</label>
                            <input type="text" class="form-control" name="bord[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Montant</label>
                            <input type="text" class="form-control" name="montant[]"/>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 14</label>
                            <input type="text" class="form-control" name="site[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Bord</label>
                            <input type="text" class="form-control" name="bord[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>Montant</label>
                            <input type="text" class="form-control" name="montant[]"/>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col"></div>
        </div>

        <div class="row">
            <div class="col">
                <div class="form-group">
                    <label>kmArrivee</label>
                    <input type="text" class="form-control" name="kmArrivee"/>
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label>heureArrivee</label>
                    <input type="text" class="form-control" name="heureArrivee"/>
                </div>
            </div>

            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>vidangeGenerale</label>
                            <input type="number" class="form-control" name="vidangeGenerale"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>visiteTechnique</label>
                            <input type="number" class="form-control" name="visiteTechnique"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>vidangeCourroie</label>
                            <input type="number" class="form-control" name="vidangeCourroie"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>patente</label>
                            <input type="number" class="form-control" name="patente"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>assuranceFin</label>
                            <input type="number" class="form-control" name="assuranceFin"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>assuranceHeurePont</label>
                            <input type="number" class="form-control" name="assuranceHeurePont"/>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Valider</button>
    </form>
</div>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\BAFACOM\Documents\burval\kawa\resources\views/transport/arrivee-tournee/index.blade.php ENDPATH**/ ?>