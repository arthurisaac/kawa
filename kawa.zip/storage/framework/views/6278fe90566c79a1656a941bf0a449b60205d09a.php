<?php $__env->startSection('main'); ?>
<div class="burval-container">
    <div><h2 class="heading">Site</h2></div>
    <br/>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <br/>
    <?php endif; ?>

    <br/>
    <p>DEPART TOURNEE</p>
    <table class="table table-bordered table-hover" id="listeDepartTournee">
        <thead>
        <tr>
            <td>N°Tournée</td>
            <td>Date</td>
            <td>Heure</td>
            <td>Code</td>
            <td>Km départ</td>
            <td>Observation</td>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $departCentres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($depart->noTournee); ?></td>
            <td><?php echo e($depart->date); ?></td>
            <td><?php echo e($depart->heureDepart); ?></td>
            <td><?php echo e($depart->code); ?></td>
            <td><?php echo e($depart->kmDepart); ?></td>
            <td><?php echo e($depart->observation); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <br/>
    <p>ARRIVEE CENTRE</p>
    <table class="table table-bordered table-hover" style="width: 100%"  id="listeArriveeTournee">
        <thead>
        <tr>
            <td>Site</td>
            <td>Date</td>
            <td>Heure</td>
            <td>Km départ</td>
            <td>Observation</td>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $arriveeCentres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($depart->site); ?></td>
            <td><?php echo e($depart->date); ?></td>
            <td><?php echo e($depart->heureDepart); ?></td>
            <td><?php echo e($depart->kmDepart); ?></td>
            <td><?php echo e($depart->observation); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <br/>
    <p>MOUVEMENT CENTRE</p>
    <table class="table table-bordered table-hover" style="width: 100%">
        <thead>
        <tr>
            <td>Date</td>
            <td>N°Tournee</td>
            <td>Vehicule</td>
            <td>Temps tournée</td>
            <td>Km parcouru</td>
            <td>Observe départ</td>
            <td>Observ arrivée</td>
        </tr>
        </thead>
        <tbody>
        </tbody>
    </table>

    <br/>
    <p>MOUVEMENT CENTRE</p>
    <table class="table table-bordered table-hover" style="width: 100%">
        <thead>
        <tr>
            <td>Site</td>
            <td>Date</td>
            <td>Heure</td>
            <td>Km arrivée</td>
            <td>N°Tournée</td>
            <td>Code</td>
        </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
    <br/>

    <p>MOUVEMENT CENTRE</p>
    <table class="table table-bordered table-hover" style="width: 100%">
        <thead>
        <tr>
            <td>Site</td>
            <td>Date</td>
            <td>Heure</td>
            <td>Num tournée</td>
            <td>Type colis</td>
            <td>Nombre de colis</td>
            <td>N°Sécuripack</td>
            <td>Destination</td>
            <td>Observation</td>
            <td>Numéro bordereau</td>
        </tr>
        </thead>
        <tbody>
        </tbody>
    </table>

    <p>POINTAGE SITE</p>
    <table class="table table-bordered table-hover" style="width: 100%">
        <thead>
        <tr>
            <td>Date</td>
            <td>N°Tournée</td>
            <td>Site</td>
            <td>Heure arrivée</td>
            <td>Heure dep</td>
            <td>Duree</td>
            <td>Observation</td>
        </tr>
        </thead>
        <tbody>
        </tbody>
    </table>



</div>
<script>
    $(document).ready(function () {
        $('#listeDepartTournee').DataTable({
            "language": {
                "url": "French.json"
            }
        });
        $('#listeArriveeTournee').DataTable({
            "language": {
                "url": "French.json"
            }
        });

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\BAFACOM\Documents\burval\kawa\resources\views//securite/maincourante/liste.blade.php ENDPATH**/ ?>