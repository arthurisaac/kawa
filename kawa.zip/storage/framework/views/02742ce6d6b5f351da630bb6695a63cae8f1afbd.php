<?php $__env->startSection('main'); ?>
<div class="row">
    <div class="col">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div><br />
        <?php endif; ?>

        <form method="post" action="<?php echo e(route('vehicule.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>immatriculation</label>
                <input type="text" class="form-control" name="immatriculation"/>
            </div>
            <div class="form-group">
                <label>photo</label>
                <input type="text" class="form-control" name="photo"/>
            </div>
            <div class="form-group">
                <label>marque</label>
                <input type="text" class="form-control" name="marque"/>
            </div>
            <div class="form-group">
                <label>type</label>
                <input type="text" class="form-control" name="type"/>
            </div>
            <div class="form-group">
                <label>code</label>
                <input type="text" class="form-control" name="code"/>
            </div>
            <div class="form-group">
                <label>num_chassis</label>
                <input type="text" class="form-control" name="num_chassis"/>
            </div>
            <div class="form-group">
                <label>DPMC</label>
                <input type="text" class="form-control" name="DPMC"/>
            </div>
            <div class="form-group">
                <label>dateAcquisition</label>
                <input type="text" class="form-control" name="dateAcquisition"/>
            </div>
            <div class="form-group">
                <label>centre</label>
                <input type="text" class="form-control" name="centre"/>
            </div>
            <div class="form-group">
                <label>centreRegional</label>
                <input type="text" class="form-control" name="centreRegional"/>
            </div>
            <div class="form-group">
                <label>chauffeurTitulaireNom</label>
                <input type="text" class="form-control" name="chauffeurTitulaireNom"/>
            </div>
            <div class="form-group">
                <label>chauffeurTitulairePrenom</label>
                <input type="text" class="form-control" name="chauffeurTitulairePrenom"/>
            </div>
            <div class="form-group">
                <label>chauffeurTitulaireFonction</label>
                <input type="text" class="form-control" name="chauffeurTitulaireFonction"/>
            </div>
            <div class="form-group">
                <label>chauffeurTitulaireMatricule</label>
                <input type="text" class="form-control" name="chauffeurTitulaireMatricule"/>
            </div>
            <div class="form-group">
                <label>chauffeurTitulaireDateAffection</label>
                <input type="text" class="form-control" name="chauffeurTitulaireDateAffection"/>
            </div>
            <div class="form-group">
                <label>chauffeurSuppleantNom</label>
                <input type="text" class="form-control" name="chauffeurSuppleantNom"/>
            </div>
            <div class="form-group">
                <label>chauffeurSuppleantPrenom</label>
                <input type="text" class="form-control" name="chauffeurSuppleantPrenom"/>
            </div>
            <div class="form-group">
                <label>chauffeurSuppleantFonction</label>
                <input type="text" class="form-control" name="chauffeurSuppleantFonction"/>
            </div>
            <div class="form-group">
                <label>chauffeurSuppleantMatricule</label>
                <input type="text" class="form-control" name="chauffeurSuppleantMatricule"/>
            </div>
            <div class="form-group">
                <label>chauffeurSuppleantDateAffection</label>
                <input type="text" class="form-control" name="chauffeurSuppleantDateAffection"/>
            </div>

            <button type="submit" class="btn btn-primary-outline">Valider</button>
        </form>
    </div>
</div>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arthur\Documents\burval\kawa\resources\views/transport/vehicule/index.blade.php ENDPATH**/ ?>