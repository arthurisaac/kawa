<?php $__env->startSection('main'); ?>
<div class="row">
    <div class="col-sm-12">
        <table class="table table-bordered table-hover" style="width: 100%" id="liste">
            <thead>
            <tr>
                <td>Immatriculation</td>
                <td>Marque</td>
                <td>Type</td>
                <td>Code</td>
                <td>N°Chassis</td>
                <td>DPMC</td>
                <td>Date acquisition</td>
                <td>centre</td>
                <td>Centre Régional</td>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $vehicules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($vehicule->immatriculation); ?></td>
                <td><?php echo e($vehicule->marque); ?></td>
                <td><?php echo e($vehicule->type); ?></td>
                <td><?php echo e($vehicule->code); ?></td>
                <td><?php echo e($vehicule->num_chassis); ?></td>
                <td><?php echo e($vehicule->DPMC); ?></td>
                <td><?php echo e($vehicule->dateAcquisition); ?></td>
                <td><?php echo e($vehicule->centre); ?></td>
                <td><?php echo e($vehicule->centreRegional); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<script>
    $(document).ready(function () {
        $('#liste').DataTable({
            "language": {
                "url": "French.json"
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\BAFACOM\Documents\burval\kawa\resources\views/transport/vehicule/liste.blade.php ENDPATH**/ ?>