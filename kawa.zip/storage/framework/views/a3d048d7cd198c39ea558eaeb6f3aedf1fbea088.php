

<?php $__env->startSection('main'); ?>
<div class="burval-container">
    <div><h2 class="heading">Départ tournée</h2></div>
    <br/>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <br/>
    <?php endif; ?>

    <form method="post" action="<?php echo e(route('depart-tournee.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col">
                <div class="form-group">
                    <label>N°Tournée:</label>
                    <input type="text" class="form-control" name="numeroTournee"/>
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label>Date</label>
                    <input type="date" class="form-control" name="date"/>
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label>Véhicule</label>
                    <select class="form-control" name="idVehicule">
                        <option>Selectionnez véhicule</option>
                        <?php $__currentLoopData = $vehicules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($vehicule->id); ?>"><?php echo e($vehicule->immatriculation); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col"></div>
        </div>
        <div class="row">
            <div class="col">
                <div class="form-group">
                    <label>Chauffeur</label>
                    <select class="form-control" name="chauffeur">
                        <option></option>
                        <?php $__currentLoopData = $chauffeurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chauffeur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($chauffeur->id); ?>"><?php echo e($chauffeur->nomPrenoms); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label>Agent de garde</label>
                    <select class="form-control" name="agentDeGarde">
                        <option></option>
                        <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($agent->id); ?>"><?php echo e($agent->nomPrenoms); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label>Chef de bord</label>
                    <select class="form-control" name="chefDeBord">
                        <option></option>
                        <?php $__currentLoopData = $chefBords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chef): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($chef->id); ?>"><?php echo e($chef->nomPrenoms); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label>Coût tournée</label>
                    <input type="number" class="form-control" min="0" name="coutTournee"/>
                </div>
            </div>
        </div><br />

        <div class="row">
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 1</label>
                            <select class="form-control" name="site[]">
                                <option></option>
                                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($site->id); ?>"><?php echo e($site->site); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>heure</label>
                            <input type="time" class="form-control" name="heure[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>type</label>
                            <select class="form-control" name="type[]">
                                <option></option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="CC">CC</option>
                                <option value="DD">DD</option>
                            </select>
                        </div>
                    </div>
                </div>

            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 8</label>
                            <select class="form-control" name="site[]">
                                <option></option>
                                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($site->id); ?>"><?php echo e($site->site); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>heure</label>
                            <input type="time" class="form-control" name="heure[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>type</label>
                            <select class="form-control" name="type[]">
                                <option></option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="CC">CC</option>
                                <option value="DD">DD</option>
                            </select>
                        </div>
                    </div>
                </div>

            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 15</label>
                            <select class="form-control" name="site[]">
                                <option></option>
                                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($site->id); ?>"><?php echo e($site->site); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>heure</label>
                            <input type="time" class="form-control" name="heure[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>type</label>
                            <select class="form-control" name="type[]">
                                <option></option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="CC">CC</option>
                                <option value="DD">DD</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 2</label>
                            <select class="form-control" name="site[]">
                                <option></option>
                                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($site->id); ?>"><?php echo e($site->site); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>heure</label>
                            <input type="time" class="form-control" name="heure[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>type</label>
                            <select class="form-control" name="type[]">
                                <option></option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="CC">CC</option>
                                <option value="DD">DD</option>
                            </select>
                        </div>
                    </div>
                </div>

            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 9</label>
                            <select class="form-control" name="site[]">
                                <option></option>
                                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($site->id); ?>"><?php echo e($site->site); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>heure</label>
                            <input type="time" class="form-control" name="heure[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>type</label>
                            <select class="form-control" name="type[]">
                                <option></option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="CC">CC</option>
                                <option value="DD">DD</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 16</label>
                            <select class="form-control" name="site[]">
                                <option></option>
                                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($site->id); ?>"><?php echo e($site->site); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col"><div class="form-group">
                            <label>heure</label>
                            <input type="time" class="form-control" name="heure[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>type</label>
                            <select class="form-control" name="type[]">
                                <option></option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="CC">CC</option>
                                <option value="DD">DD</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 3</label>
                            <select class="form-control" name="site[]">
                                <option></option>
                                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($site->id); ?>"><?php echo e($site->site); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>heure</label>
                            <input type="time" class="form-control" name="heure[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>type</label>
                            <select class="form-control" name="type[]">
                                <option></option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="CC">CC</option>
                                <option value="DD">DD</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 10</label>
                            <select class="form-control" name="site[]">
                                <option></option>
                                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($site->id); ?>"><?php echo e($site->site); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>heure</label>
                            <input type="time" class="form-control" name="heure[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>type</label>
                            <select class="form-control" name="type[]">
                                <option></option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="CC">CC</option>
                                <option value="DD">DD</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 17</label>
                            <select class="form-control" name="site[]">
                                <option></option>
                                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($site->id); ?>"><?php echo e($site->site); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>heure</label>
                            <input type="time" class="form-control" name="heure[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>type</label>
                            <select class="form-control" name="type[]">
                                <option></option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="CC">CC</option>
                                <option value="DD">DD</option>
                            </select>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 4</label>
                            <select class="form-control" name="site[]">
                                <option></option>
                                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($site->id); ?>"><?php echo e($site->site); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>heure</label>
                            <input type="time" class="form-control" name="heure[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>type</label>
                            <select class="form-control" name="type[]">
                                <option></option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="CC">CC</option>
                                <option value="DD">DD</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 11</label>
                            <select class="form-control" name="site[]">
                                <option></option>
                                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($site->id); ?>"><?php echo e($site->site); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>heure</label>
                            <input type="time" class="form-control" name="heure[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>type</label>
                            <select class="form-control" name="type[]">
                                <option></option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="CC">CC</option>
                                <option value="DD">DD</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 18</label>
                            <select class="form-control" name="site[]">
                                <option></option>
                                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($site->id); ?>"><?php echo e($site->site); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>heure</label>
                            <input type="time" class="form-control" name="heure[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>type</label>
                            <select class="form-control" name="type[]">
                                <option></option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="CC">CC</option>
                                <option value="DD">DD</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 5</label>
                            <select class="form-control" name="site[]">
                                <option></option>
                                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($site->id); ?>"><?php echo e($site->site); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>heure</label>
                            <input type="time" class="form-control" name="heure[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>type</label>
                            <select class="form-control" name="type[]">
                                <option></option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="CC">CC</option>
                                <option value="DD">DD</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 12</label>
                            <select class="form-control" name="site[]">
                                <option></option>
                                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($site->id); ?>"><?php echo e($site->site); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>heure</label>
                            <input type="time" class="form-control" name="heure[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>type</label>
                            <select class="form-control" name="type[]">
                                <option></option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="CC">CC</option>
                                <option value="DD">DD</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 19</label>
                            <select class="form-control" name="site[]">
                                <option></option>
                                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($site->id); ?>"><?php echo e($site->site); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>heure</label>
                            <input type="time" class="form-control" name="heure[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>type</label>
                            <select class="form-control" name="type[]">
                                <option value="C">C</option>
                                <option></option>
                                <option value="D">D</option>
                                <option value="CC">CC</option>
                                <option value="DD">DD</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 6</label>
                            <select class="form-control" name="site[]">
                                <option></option>
                                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($site->id); ?>"><?php echo e($site->site); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>heure</label>
                            <input type="time" class="form-control" name="heure[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>type</label>
                            <select class="form-control" name="type[]">
                                <option></option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="CC">CC</option>
                                <option value="DD">DD</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 13</label>
                            <select class="form-control" name="site[]">
                                <option></option>
                                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($site->id); ?>"><?php echo e($site->site); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>heure</label>
                            <input type="time" class="form-control" name="heure[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>type</label>
                            <select class="form-control" name="type[]">
                                <option></option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="CC">CC</option>
                                <option value="DD">DD</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 20</label>
                            <select class="form-control" name="site[]">
                                <option></option>
                                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($site->id); ?>"><?php echo e($site->site); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>heure</label>
                            <input type="time" class="form-control" name="heure[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>type</label>
                            <select class="form-control" name="type[]">
                                <option></option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="CC">CC</option>
                                <option value="DD">DD</option>
                            </select>
                        </div>
                    </div>
                </div>


            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 6</label>
                            <select class="form-control" name="site[]">
                                <option></option>
                                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($site->id); ?>"><?php echo e($site->site); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>heure</label>
                            <input type="time" class="form-control" name="heure[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>type</label>
                            <select class="form-control" name="type[]">
                                <option></option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="CC">CC</option>
                                <option value="DD">DD</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Site 13</label>
                            <select class="form-control" name="site[]">
                                <option></option>
                                <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($site->id); ?>"><?php echo e($site->site); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>heure</label>
                            <input type="time" class="form-control" name="heure[]"/>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>type</label>
                            <select class="form-control" name="type[]">
                                <option></option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="CC">CC</option>
                                <option value="DD">DD</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <br />
                <button class="btn btn-primary">Enregistrer</button>
                <button class="btn btn-danger">Annuler</button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\BAFACOM\Documents\burval\kawa\resources\views/transport/depart-tournee/index.blade.php ENDPATH**/ ?>