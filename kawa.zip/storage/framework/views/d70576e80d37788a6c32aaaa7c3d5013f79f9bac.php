<?php $__env->startSection('main'); ?>
<div class="row">
    <div class="col-sm-8 offset-sm-2">
        <h1 class="display-3">Securite service</h1>
        <div>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div><br />
            <?php endif; ?>
            <form method="post" action="<?php echo e(route('securite-service.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label>Date</label>
                    <input type="date" class="form-control" name="date"/>
                </div>
                <div class="form-group">
                    <label>centre</label>
                    <input type="text" class="form-control" name="centre"/>
                </div>
                <div class="form-group">
                    <label>centreRegional</label>
                    <input type="text" class="form-control" name="centreRegional"/>
                </div>
                <div class="form-group">
                    <label>nomChargeDeSecurite</label>
                    <input type="text" class="form-control" name="nomChargeDeSecurite"/>
                </div>
                <div class="form-group">
                    <label>prenomChargeDeSecurite</label>
                    <input type="text" class="form-control" name="prenomChargeDeSecurite"/>
                </div>
                <div class="form-group">
                    <label>fonctionChargeDeSecurite</label>
                    <input type="text" class="form-control" name="fonctionChargeDeSecurite"/>
                </div>
                <div class="form-group">
                    <label>matriculeChargeDeSecurite</label>
                    <input type="text" class="form-control" name="matriculeChargeDeSecurite"/>
                </div>
                <div class="form-group">
                    <label>heureDePriseServiceCs</label>
                    <input type="text" class="form-control" name="heureDePriseServiceCs"/>
                </div>
                <div class="form-group">
                    <label>csHeureDeFinDeService</label>
                    <input type="text" class="form-control" name="csHeureDeFinDeService"/>
                </div>

                <div class="form-group">
                    <label>eop11Nom</label>
                    <input type="text" class="form-control" name="eop11Nom"/>
                </div>
                <div class="form-group">
                    <label>eop11Prenom</label>
                    <input type="text" class="form-control" name="eop11Prenom"/>
                </div>
                <div class="form-group">
                    <label>eop11Fonction</label>
                    <input type="text" class="form-control" name="eop11Fonction"/>
                </div>
                <div class="form-group">
                    <label>eop11Matricule</label>
                    <input type="text" class="form-control" name="eop11Matricule"/>
                </div>
                <div class="form-group">
                    <label>eop11HeurePriseServ</label>
                    <input type="text" class="form-control" name="eop11HeurePriseServ"/>
                </div>
                <div class="form-group">
                    <label>eop11HeureFinService</label>
                    <input type="text" class="form-control" name="eop11HeureFinService"/>
                </div>
                <div class="form-group">
                    <label>eop112Nom</label>
                    <input type="text" class="form-control" name="eop112Nom"/>
                </div>
                <div class="form-group">
                    <label>eop12Prenom</label>
                    <input type="text" class="form-control" name="eop12Prenom"/>
                </div>
                <div class="form-group">
                    <label>eop12Fonction</label>
                    <input type="text" class="form-control" name="eop12Fonction"/>
                </div>
                <div class="form-group">
                    <label>eop12Matricule</label>
                    <input type="text" class="form-control" name="eop12Matricule"/>
                </div>
                <div class="form-group">
                    <label>eop12HeurePriseServ</label>
                    <input type="text" class="form-control" name="eop12HeurePriseServ"/>
                </div>
                <div class="form-group">
                    <label>eop12HeureFinService</label>
                    <input type="text" class="form-control" name="eop12HeureFinService"/>
                </div>
                <div class="form-group">
                    <label>eop21Nom</label>
                    <input type="text" class="form-control" name="eop21Nom"/>
                </div>
                <div class="form-group">
                    <label>eop21Prenom</label>
                    <input type="text" class="form-control" name="eop21Prenom"/>
                </div>
                <div class="form-group">
                    <label>eop21Fonction</label>
                    <input type="text" class="form-control" name="eop21Fonction"/>
                </div>
                <div class="form-group">
                    <label>eop21Matricule</label>
                    <input type="text" class="form-control" name="eop21Matricule"/>
                </div>
                <div class="form-group">
                    <label>eop21HeurePriseServ</label>
                    <input type="text" class="form-control" name="eop21HeurePriseServ"/>
                </div>
                <div class="form-group">
                    <label>eop21HeureFinService</label>
                    <input type="text" class="form-control" name="eop21HeureFinService"/>
                </div>
                <div class="form-group">
                    <label>eop22Nom</label>
                    <input type="text" class="form-control" name="eop22Nom"/>
                </div>
                <div class="form-group">
                    <label>eop22Prenom</label>
                    <input type="text" class="form-control" name="eop22Prenom"/>
                </div>
                <div class="form-group">
                    <label>eop22Fonction</label>
                    <input type="text" class="form-control" name="eop22Fonction"/>
                </div>
                <div class="form-group">
                    <label>eop22Matricule</label>
                    <input type="text" class="form-control" name="eop22Matricule"/>
                </div>
                <div class="form-group">
                    <label>eop22HeurePriseServ</label>
                    <input type="text" class="form-control" name="eop22HeurePriseServ"/>
                </div>
                <div class="form-group">
                    <label>eop22HeureFinService</label>
                    <input type="text" class="form-control" name="eop22HeureFinService"/>
                </div>
                <div class="form-group">
                    <label>eop31Nom</label>
                    <input type="text" class="form-control" name="eop31Nom"/>
                </div>
                <div class="form-group">
                    <label>eop31Prenom</label>
                    <input type="text" class="form-control" name="eop31Prenom"/>
                </div>
                <div class="form-group">
                    <label>eop31Fonction</label>
                    <input type="text" class="form-control" name="eop31Fonction"/>
                </div>
                <div class="form-group">
                    <label>eop31Matricule</label>
                    <input type="text" class="form-control" name="eop31Matricule"/>
                </div>
                <div class="form-group">
                    <label>eop31HeurePriseServ</label>
                    <input type="text" class="form-control" name="eop31HeurePriseServ"/>
                </div>
                <div class="form-group">
                    <label>eop31HeureFinService</label>
                    <input type="text" class="form-control" name="eop31HeureFinService"/>
                </div>
                <div class="form-group">
                    <label>eop32Nom</label>
                    <input type="text" class="form-control" name="eop32Nom"/>
                </div>
                <div class="form-group">
                    <label>eop32Prenom</label>
                    <input type="text" class="form-control" name="eop32Prenom"/>
                </div>
                <div class="form-group">
                    <label>eop32Fonction</label>
                    <input type="text" class="form-control" name="eop32Fonction"/>
                </div>
                <div class="form-group">
                    <label>eop32Matricule</label>
                    <input type="text" class="form-control" name="eop32Matricule"/>
                </div>
                <div class="form-group">
                    <label>eop32HeurePriseServ</label>
                    <input type="text" class="form-control" name="eop32HeurePriseServ"/>
                </div>
                <div class="form-group">
                    <label>eop32HeureFinService</label>
                    <input type="text" class="form-control" name="eop32HeureFinService"/>
                </div>

                <button type="submit" class="btn btn-primary-outline">Valider</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arthur\Documents\burval\kawa\resources\views/securiteService/create.blade.php ENDPATH**/ ?>