<?php $__env->startSection('main'); ?>
<div class="row">
    <div class="col-sm-12">
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                <td>Date</td>
                <td>Centre</td>
                <td>Cs Nom</td>
                <td>Cs Prénom</td>
                <td>Cs Fonction</td>
                <td>Cs Matricule</td>
                <td>Cs HPS</td>
                <td>Cs HFS</td>
                <td>EQ1 OR1 Nom</td>
                <td>EQ1 OR1 Prénom</td>
                <td>EQ1 OR1 Fonction</td>
                <td>EQ1 OR1 Matricule</td>
                <td>EQ1 OR1 HPS</td>
                <td>EQ1 OR1 HFS</td>
                <td>EQ1 OR2 Nom</td>
                <td>EQ1 OR2 Prénom</td>
                <td>EQ1 OR2 Fonction</td>
                <td>EQ1 OR2 Matricule</td>
                <td>EQ1 OR2 HPS</td>
                <td>EQ1 OR2 HFS</td>
                <td>EQ2 OR1 Nom</td>
                <td>EQ2 OR1 Prénom</td>
                <td>EQ2 OR1 Fonction</td>
                <td>EQ2 OR1 Matricule</td>
                <td>EQ2 OR1 HPS</td>
                <td>EQ2 OR1 HFS</td>
                <td>EQ2 OR2 Nom</td>
                <td>EQ2 OR2 Prénom</td>
                <td>EQ2 OR2 Fonction</td>
                <td>EQ2 OR2 Matricule</td>
                <td>EQ2 OR2 HPS</td>
                <td>EQ2 OR2 HFS</td>
                <td>EQ3 OR1 Nom</td>
                <td>EQ3 OR1 Prénom</td>
                <td>EQ3 OR1 Fonction</td>
                <td>EQ3 OR1 Matricule</td>
                <td>EQ3 OR1 HPS</td>
                <td>EQ3 OR1 HFS</td>
                <td>EQ3 OR2 Nom</td>
                <td>EQ3 OR2 Prénom</td>
                <td>EQ3 OR2 Fonction</td>
                <td>EQ3 OR2 Matricule</td>
                <td>EQ3 OR2 HPS</td>
                <td>EQ3 OR2 HFS</td>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $securiteServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($service->date); ?></td>
                <td><?php echo e($service->centre); ?></td>
                <td><?php echo e($service->nomChargeDeSecurite); ?></td>
                <td><?php echo e($service->prenomChargeDeSecurite); ?></td>
                <td><?php echo e($service->fonctionChargeDeSecurite); ?></td>
                <td><?php echo e($service->matriculeChargeDeSecurite); ?></td>
                <td><?php echo e($service->heureDePriseServiceCs); ?></td>
                <td><?php echo e($service->csHeureDeFinDeService); ?></td>
                <td><?php echo e($service->eop11Nom); ?></td>
                <td><?php echo e($service->eop11Prenom); ?></td>
                <td><?php echo e($service->eop11Fonction); ?></td>
                <td><?php echo e($service->eop11Matricule); ?></td>
                <td><?php echo e($service->eop11HeurePriseServ); ?></td>
                <td><?php echo e($service->eop11HeureFinService); ?></td>
                <td><?php echo e($service->eop112Nom); ?></td>
                <td><?php echo e($service->eop12Prenom); ?></td>
                <td><?php echo e($service->eop12Fonction); ?></td>
                <td><?php echo e($service->eop12Matricule); ?></td>
                <td><?php echo e($service->eop12HeurePriseServ); ?></td>
                <td><?php echo e($service->eop12HeureFinService); ?></td>
                <td><?php echo e($service->eop21Nom); ?></td>
                <td><?php echo e($service->eop21Prenom); ?></td>
                <td><?php echo e($service->eop21Fonction); ?></td>
                <td><?php echo e($service->eop21Matricule); ?></td>
                <td><?php echo e($service->eop21HeurePriseServ); ?></td>
                <td><?php echo e($service->eop21HeureFinService); ?></td>
                <td><?php echo e($service->eop22Nom); ?></td>
                <td><?php echo e($service->eop22Prenom); ?></td>
                <td><?php echo e($service->eop22Fonction); ?></td>
                <td><?php echo e($service->eop22Matricule); ?></td>
                <td><?php echo e($service->eop22HeurePriseServ); ?></td>
                <td><?php echo e($service->eop22HeureFinService); ?></td>
                <td><?php echo e($service->eop31Nom); ?></td>
                <td><?php echo e($service->eop31Prenom); ?></td>
                <td><?php echo e($service->eop31Fonction); ?></td>
                <td><?php echo e($service->eop31Matricule); ?></td>
                <td><?php echo e($service->eop31HeurePriseServ); ?></td>
                <td><?php echo e($service->eop31HeureFinService); ?></td>
                <td><?php echo e($service->eop32Nom); ?></td>
                <td><?php echo e($service->eop32Prenom); ?></td>
                <td><?php echo e($service->eop32Fonction); ?></td>
                <td><?php echo e($service->eop32Matricule); ?></td>
                <td><?php echo e($service->eop32HeurePriseServ); ?></td>
                <td><?php echo e($service->eop32HeureFinService); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\BAFACOM\Documents\burval\kawa\resources\views/securiteService/liste.blade.php ENDPATH**/ ?>