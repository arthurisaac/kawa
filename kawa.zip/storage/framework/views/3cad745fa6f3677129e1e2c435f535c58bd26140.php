<?php $__env->startSection('main'); ?>
<div class="burval-container">
    <div><h2 class="heading">Vidange huile de pont</h2></div>
    <br/>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <br/>
    <?php endif; ?>

    <form method="post" action="<?php echo e(route('vidange-pont.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-4">
                <div class="form-group row">
                    <label class="col-md-4">Date</label>
                    <input type="date" class="form-control col-md-8" name="date"/>
                </div>
                <div class="form-group row">
                    <label class="col-md-4">Véhicule</label>
                    <select class="form-control form-control-sm col-md-8" name="idVehicule">
                        <option>Selectionnez véhicule</option>
                        <?php $__currentLoopData = $vehicules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($vehicule->id); ?>"><?php echo e($vehicule->immatriculation); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group row">
                    <label class="col-md-4">Centre</label>
                    <select class="form-control form-control-sm col-md-8" name="centre" id="centre" required>
                        <option>Choisir centre</option>
                        <?php $__currentLoopData = $centres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($centre->centre); ?>"><?php echo e($centre->centre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group row">
                    <label class="col-md-4">Centre régional</label>
                    <select class="form-control form-control-sm col-md-8" name="centreRegional" id="centre_regional"
                            required></select>
                </div>
                <div class="form-group row">
                    <label class="col-md-4">Km actuel</label>
                    <input type="number" class="form-control form-control-sm col-md-8" name="kmActuel"/>
                </div>
                <div class="form-group row">
                    <label class="col-md-4">Prochain km</label>
                    <input type="number" class="form-control form-control-sm col-md-8" name="prochainKm"/>
                </div>
            </div>
            <div class="col-2">
                <button type="submit" class="btn btn-primary btn-block btn-sm">Valider</button>
                <br/>
                <button type="reset" class="btn btn-danger btn-block btn-sm">Annuler</button>
                <br/>
            </div>
            <div class="col-6">
                <table class="table table-bordered" id="liste">
                    <thead>
                    <tr>
                        <th>Véhicule</th>
                        <th>Total vidange</th>
                        <th>Prochaine vidange</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $vidanges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vidange): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($vidange->idVehicule); ?></td>
                    <td><?php echo e($vidange->huileMoteurmontant + $vidange->filtreHuileMontant + $vidange->filtreGazoilMontant + $vidange->filtreAirMontant); ?></td>
                    <!--<td><?php echo e(date('Y-m-d H:i:s'), strtotime($vidange->date. ' + 5 days')); ?></td>-->
                    <td><?php echo e(date('d/m/Y', strtotime($vidange->date . " + 7 day"))); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <br/>

        <div class="row">
            <div class="col">
                <label>Huile de pont</label>
            </div>
            <div class="col">
                <div class="form-group">
                    <div class="form-group">
                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label>Oui</label><br/>
                                    <input type="radio" class="form-check-input col-md-10" value="1"
                                           name="huilePont"/>
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label>Non</label><br/>
                                    <input type="radio" class="form-check-input col-md-10" value="0"
                                           name="huilePont"/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label>Marque</label>
                    <input type="text" class="form-control form-control-sm" name="huilePontMarque"/>
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label>Nombre de km</label>
                    <input type="text" class="form-control form-control-sm" name="huilePontKm"/>
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label>Fournisseur</label>
                    <input type="text" class="form-control form-control-sm" name="huilePontFournisseur"/>
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label>Montant</label>
                    <input type="text" min="0" class="form-control form-control-sm" name="huilePontmontant"/>
                </div>
            </div>
        </div>
    </form>
</div>
<script>
    let centres = <?php echo json_encode($centres); ?>;
    let centres_regionaux = <?php echo json_encode($centres_regionaux); ?>;

    $(document).ready(function () {
        $("#centre").on("change", function () {
            $("#centre_regional option").remove();
            $('#centre_regional').append($('<option>', {text: "Choisir centre régional"}));

            const centre = centres.find(c => c.centre === this.value);
            const regions = centres_regionaux.filter(region => {
                return region.id_centre === centre.id;
            });
            regions.map(({centre_regional}) => {
                $('#centre_regional').append($('<option>', {
                    value: centre_regional,
                    text: centre_regional
                }));
            })
        });

        $('#liste').DataTable({
            "language": {
                "url": "French.json"
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\BAFACOM\Documents\burval\kawa\resources\views//transport/entretien-vehicule/vidange-pont/index.blade.php ENDPATH**/ ?>