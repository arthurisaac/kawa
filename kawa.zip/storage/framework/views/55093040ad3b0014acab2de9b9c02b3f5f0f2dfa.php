

<?php $__env->startSection('main'); ?>
<div class="burval-container">
    <div><h2 class="heading">Liste saisie</h2></div>
    <br/>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <br/>
    <?php endif; ?>

    <div class="row">
        <div class="col">
            <table class="table table-bordered" style="width: 100%;" id="liste">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Type jour</th>
                        <th>Nom et prénoms</th>
                        <th>Heure arrivée</th>
                        <th>Heure départ</th>
                        <th>Heure arrivée 1</th>
                        <th>Heure depart 1</th>
                        <th>Heure arrivée 2</th>
                        <th>Heure départ 2</th>
                        <th>Heure arrivée 3</th>
                        <th>Heure départ 3</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $saisies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saisie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($saisie->date); ?></td>
                            <td><?php echo e($saisie->typeDate); ?></td>
                            <td><?php echo e($saisie->personnels->nomPrenoms); ?></td>
                            <td><?php echo e($saisie->heureArrivee); ?></td>
                            <td><?php echo e($saisie->heureDepart); ?></td>
                            <td><?php echo e($saisie->heureArrivee1); ?></td>
                            <td><?php echo e($saisie->heureDepart1); ?></td>
                            <td><?php echo e($saisie->heureArrivee2); ?></td>
                            <td><?php echo e($saisie->heureDepart2); ?></td>
                            <td><?php echo e($saisie->heureArrivee3); ?></td>
                            <td><?php echo e($saisie->heureDepart3); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
    $(document).ready( function () {
        $('#liste').DataTable({
            "language": {
                "url": "French.json"
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\BAFACOM\Documents\burval\kawa\resources\views/securite/saisie/liste.blade.php ENDPATH**/ ?>