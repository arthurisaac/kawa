

<?php $__env->startSection('main'); ?>
<div class="burval-container">
    <div><h2 class="heading">Saisie</h2></div>
    <br/>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <br/>
    <?php endif; ?>

    <form method="post" action="<?php echo e(route('saisie.store')); ?>">
        <?php echo csrf_field(); ?>

        <div class="row">
            <div class="col">
                <div class="form-group row">
                    <label class="col-sm-4">Date de tournée</label>
                    <input type="date" class="form-control col-sm-8" name="date">
                </div>
                <div class="form-group row">
                    <label class="col-sm-4">Type de date</label>
                    <input type="text" class="form-control col-sm-8" name="typeDate">
                </div>
                <div class="form-group row">
                    <label class="col-sm-4">Nom et prénoms</label>
                    <select class="form-control col-sm-8" name="idPersonnel">
                        <option>Selectionnez</option>
                        <?php $__currentLoopData = $personnels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personnel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($personnel->id); ?>"><?php echo e($personnel->nomPrenoms); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-4"></div>
            <div class="col-2">
                <button class="btn btn-primary btn-sm btn-block" type="submit">Valider</button>
                <button class="btn btn-danger btn-sm btn-block" type="reset">Annuler</button>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="form-group row">
                    <label class="col-sm-4">Heure arrivée</label>
                    <input type="time" class="form-control col-sm-8" name="heureArrivee">
                </div>
                <div class="form-group row">
                    <label class="col-sm-4">Heure arrivée 1</label>
                    <input type="time" class="form-control col-sm-8" name="heureArrivee1">
                </div>
                <div class="form-group row">
                    <label class="col-sm-4">Heure arrivée 2</label>
                    <input type="time" class="form-control col-sm-8" name="heureArrivee2">
                </div>
                <div class="form-group row">
                    <label class="col-sm-4">Heure arrivée 3</label>
                    <input type="time" class="form-control col-sm-8" name="heureArrivee3">
                </div>
            </div>
            <div class="col">
                <div class="form-group row">
                    <label class="col-sm-4">Heure départ</label>
                    <input type="time" class="form-control col-sm-8" name="heureDepart">
                </div>
                <div class="form-group row">
                    <label class="col-sm-4">Heure départ 1</label>
                    <input type="time" class="form-control col-sm-8" name="heureDepart1">
                </div>
                <div class="form-group row">
                    <label class="col-sm-4">Heure départ 2</label>
                    <input type="time" class="form-control col-sm-8" name="heureDepart2">
                </div>
                <div class="form-group row">
                    <label class="col-sm-4">Heure départ 3</label>
                    <input type="time" class="form-control col-sm-8"  name="heureDepart3">
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\BAFACOM\Documents\burval\kawa\resources\views/securite/saisie/index.blade.php ENDPATH**/ ?>