<?php $__env->startSection('main'); ?>
<div class="burval-container">
    <div><h2 class="heading">Client</h2></div>
    <br/>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <br/>
    <?php endif; ?>

    <br/>
    <table id="table_client_informations" class="table table-bordered table-hover">
        <thead>
        <tr>
            <th scope="col">Client</th>
            <th scope="col">Boite postale</th>
            <th scope="col">Tel</th>
            <th scope="col">Situation géographique</th>
            <th scope="col">Nom contact</th>
            <th scope="col">Fonction</th>
            <th scope="col">Ville</th>
            <th scope="col">Mail</th>
            <th scope="col">Cel</th>
            <th scope="col">Regime imposition</th>
            <th scope="col">Regime commerce</th>
            <th scope="col">N° Fiscal</th>
            <th scope="col">Nbre operation</th>
            <th scope="col">Contrat</th>
            <th scope="col">Portefeuille</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($client->client_nom); ?></td>
                <td><?php echo e($client->client_boite_postale); ?></td>
                <td><?php echo e($client->client_tel); ?></td>
                <td><?php echo e($client->client_situation_geographique); ?></td>
                <td><?php echo e($client->contact_nom); ?></td>
                <td><?php echo e($client->contact_fonction); ?></td>
                <td><?php echo e($client->client_ville); ?></td>
                <td><?php echo e($client->contact_email); ?></td>
                <td><?php echo e($client->contact_portable); ?></td>
                <td><?php echo e($client->contrat_regime); ?></td>
                <td></td>
                <td></td>
                <td></td>
                <td><?php echo e($client->contrat_numero); ?></td>
                <td><?php echo e($client->contact_portefeuille); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>

    <br />
    <table id="table_client_base_tarifaire" class="table table-bordered table-hover">
        <thead>
        <tr>
            <th scope="col">TDF VB</th>
            <th scope="col">TDF VL</th>
            <th scope="col">MAD Caisse</th>
            <th scope="col">Collecte</th>
            <th scope="col">Petit matériel Sécuripack</th>
            <th scope="col">Petit matériel Sac jute</th>
            <th scope="col">Petit matériel scellé</th>
            <th scope="col">Garde de fonds C.U</th>
            <th scope="col">Garde de fond M.G</th>
            <th scope="col">Garde de fond C.F</th>
            <th scope="col">Garde de fond Montant gardé</th>
            <th scope="col">Comptage de trie cout unitaire</th>
            <th scope="col">Comptage de trie montant CTV</th>
            <th scope="col">Gestion ATM</th>
            <th scope="col">Maintenance ATM</th>
            <th scope="col">Consommable ATM</th>
        </tr
        </thead>
        <tbody>
        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
               <td><?php echo e($client->base_tdf_vb); ?></td>
               <td><?php echo e($client->base_tdf_vl); ?></td>
               <td><?php echo e($client->base_mad_caisse); ?></td>
               <td><?php echo e($client->base_collecte); ?></td>
               <td><?php echo e($client->base_petit_materiel_securipack); ?></td>
               <td><?php echo e($client->base_petit_materiel_sacjute); ?></td>
               <td><?php echo e($client->base_petit_materiel_scelle); ?></td>
               <td><?php echo e($client->base_garde_de_fonds_cout_unitaire); ?></td>
               <td><?php echo e($client->base_garde_de_fonds_montant_garde_cu); ?></td>
               <td><?php echo e($client->base_garde_de_fonds_cout_forfetaire); ?></td>
               <td><?php echo e($client->base_garde_de_fonds_montant_garde_cf); ?></td>
               <td><?php echo e($client->base_comptage_tri_cout_unitaire); ?></td>
               <td><?php echo e($client->base_comptage_tri_montant_ctv); ?></td>
               <td><?php echo e($client->base_gestion_atm); ?></td>
               <td><?php echo e($client->base_maintenance_atm); ?></td>
               <td><?php echo e($client->base_consommable_atm); ?></td>
           </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <br />
    <table id="table_client_base_contrat" class="table table-bordered table-hover">
        <thead>
        <tr>
            <th scope="col">Contrat</th>
            <!--<th scope="col">Objet VB</th>
            <th scope="col">Objet SI</th>-->
            <th scope="col">Caisse</th>
            <!--<th scope="col">Collecte</th>-->
            <th scope="col">gdf</th>
            <th scope="col">Comptage</th>
            <th scope="col">Gestion ATM</th>
            <th scope="col">Collecte</th>
            <th scope="col">Comptage tri</th>
            <th scope="col">RéGIMEEM</th>
            <th scope="col">dEESSESTBC</th>
            <th scope="col">dESSERTEAP</th>
            <th scope="col">dESSERTAS</th>
            <th scope="col">dESSERTCP</th>
            <th scope="col">FREQUENCEOP</th>
            <th scope="col">DATEFFET</th>
            <th scope="col">Durée</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($client->contrat_numero); ?></td>
                <td></td>
                <td></td>
                <td></td>
                <td><?php echo e($client->bt_gestion_atm); ?></td>
                <td><?php echo e($client->bt_collecte); ?></td>
                <td><?php echo e($client->bt_comptage_tri_montant_ctv); ?></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td><?php echo e($client->contrat_date_effet); ?></td>
                <td><?php echo e($client->contrat_duree); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<script>
    $(document).ready( function () {
        $('#table_client_base_contrat').DataTable({
            "language": {
                "url": "French.json"
            }
        });
        $('#table_client_informations').DataTable({
            "language": {
                "url": "French.json"
            }
        });
        $('#table_client_base_tarifaire').DataTable({
            "language": {
                "url": "French.json"
            }
        });
    } );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\BAFACOM\Documents\burval\kawa\resources\views/commercial/client/liste.blade.php ENDPATH**/ ?>