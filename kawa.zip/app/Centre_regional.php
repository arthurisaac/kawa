<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Centre_regional extends Model
{
    //
}
